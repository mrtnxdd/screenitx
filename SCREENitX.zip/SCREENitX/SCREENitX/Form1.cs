﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SCREENitX
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (Directory.Exists("C:\\ProgramData\\SREENitX\\"))
            {
                if (File.Exists("C:\\ProgramData\\SREENitX\\app_setting.data") == false)
                {
                    MessageBox.Show("Před prvním spuštění programu je nutné vybrat, kam se budou snímky ukládat");
                    using (var fbd = new FolderBrowserDialog())
                    {
                        DialogResult result = fbd.ShowDialog();

                        if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(fbd.SelectedPath))
                        {
                            string path = fbd.SelectedPath;
                            File.WriteAllText("C:\\ProgramData\\SREENitX\\app_setting.data", path);
                        }
                    }
                }
            }
            else
            {
                Directory.CreateDirectory("C:\\ProgramData\\SREENitX");

                MessageBox.Show("Před prvním spuštění programu je nutné vybrat, kam se budou snímky ukládat");
                using (var fbd = new FolderBrowserDialog())
                {
                    DialogResult result = fbd.ShowDialog();

                    if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(fbd.SelectedPath))
                    {
                        string path = fbd.SelectedPath;
                        File.WriteAllText("C:\\ProgramData\\SREENitX\\app_setting.data", path);
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (var fbd = new FolderBrowserDialog())
            {
                DialogResult result = fbd.ShowDialog();

                if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(fbd.SelectedPath))
                {
                    string path = fbd.SelectedPath;
                    File.WriteAllText("C:\\ProgramData\\SREENitX\\app_setting.data", path);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            Thread.Sleep(150);
            string savepath = File.ReadAllText("C:\\ProgramData\\SREENitX\\app_setting.data");
            string name = DateTime.Now.ToString("yyyy'-'MM'-'dd'-'HH'-'mm'-'ss");

            Rectangle bounds = Screen.GetBounds(Point.Empty);
            using (Bitmap bitmap = new Bitmap(bounds.Width, bounds.Height))
            {
                using (Graphics g = Graphics.FromImage(bitmap))
                {
                    g.CopyFromScreen(Point.Empty, Point.Empty, bounds.Size);
                }
                bitmap.Save(savepath + "\\" + name + ".jpg", ImageFormat.Jpeg);

                dialog dialog = new dialog();
                dialog.Show();
                this.Visible = true;
            }
        }
    }
}